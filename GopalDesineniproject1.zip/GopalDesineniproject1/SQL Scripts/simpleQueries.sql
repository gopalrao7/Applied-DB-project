-- ************************************************************************
-- THIS SCRIPT RUNS THE SIMPLE QUERIES AGAINST THE MY_HOSPITAL_DB DATABASE.
-- ************************************************************************

-- 1. To get the list of all appointments that are reserved for particular physician:
SELECT  * FROM my_hospital_db.appointments WHERE STAFF_ID = '1298331751' ;

-- 2.  To get the list of all appointments that are reserved for particular physician 
-- -   and for particulardate date.
SELECT  * FROM my_hospital_db.appointments WHERE STAFF_ID = '1298331751' 
		AND DATE_FORMAT(START_DATE_TIME,'%Y-%m-%e') = '2008-04-29';

-- 3. To get the patient details based on specific gender.
SELECT * FROM PATIENT WHERE GENDER = "FEMALE";

-- 4. To update a patient detail based on ID
SELECT * FROM PATIENT WHERE PATIENT_ID = 20;
UPDATE PATIENT SET DATE_OF_BIRTH ='2002-11-01' WHERE PATIENT_ID = 20;
SELECT * FROM PATIENT WHERE PATIENT_ID = 20;

-- 5. To Delete an appointment of a patient;
-- first delete child records in another table before deleting parent record;
SELECT * FROM my_hospital_db.appointments WHERE PATIENT_ID = 11;

-- child table records to be deleted in order for parent table record to be deleted
delete from clinical_care_info where appointment_id=1983372;
delete from medication_bucket where prescription_id=58882;
delete from prescriptions where appointment_id=1983372;
-- parent table
DELETE FROM APPOINTMENTS WHERE PATIENT_ID = 11;
SELECT * FROM my_hospital_db.appointments WHERE PATIENT_ID = 11;

-- 6. Delete an order in Clinic_care_info table.
SELECT * FROM clinical_care_info WHERE order_id = '44180';
Delete from clinical_care_info where order_id = '44180';
SELECT * FROM clinical_care_info WHERE order_id = '44180';

-- 7.To update the head of the department.
SELECT * FROM DEPARTMENT WHERE DEPARTMENT_NAME = 'NURSING';
UPDATE DEPARTMENT SET DEPARTMENT_HEAD= 'Anand Rajan' where DEPARTMENT_NAME = 'NURSING';
SELECT * FROM DEPARTMENT WHERE DEPARTMENT_NAME = 'NURSING';

-- 8.To Update the discharge date and discharge diagnosis of an admitted patient
SELECT * FROM my_hospital_db.clinical_care_info where ORDER_ID = '23526';
UPDATE CLINICAL_CARE_INFO 
		SET DISCHARGE_DATE = '2008-08-11',discharge_diagnosis = 'CURED'
		where ORDER_ID = '23526';
SELECT * FROM my_hospital_db.clinical_care_info where ORDER_ID = '23526';

-- 9.To Report the patients’ expenditure to insurance provider by inserting 
-- the record into insurance table.
SELECT * FROM MY_HOSPITAL_DB.INSURANCE WHERE INSURANCE_ID = 'NW193GFBTS';
CALL MY_HOSPITAL_DB.INSURANCE_REPORTER('NW193GFBTS',234.60);
SELECT * FROM MY_HOSPITAL_DB.INSURANCE WHERE INSURANCE_ID = 'NW193GFBTS';

-- 10.To ignore appointments on special holiday day
-- failcase, gives error when trying to insert
SELECT * FROM my_hospital_db.availability_info;
UPDATE my_hospital_db.AVAILABILITY_INFO SET APPOINTMENTS_REMAINING = 0 
		WHERE DATE_OF_AVAILABILITY = '2008-04-25';
SELECT * FROM my_hospital_db.availability_info;
INSERT INTO APPOINTMENTS VALUES
(9648933,1,130300494,'2008-04-25 12:00:00','2008-04-25 13:00:00','Fever');


-- ************************************************************************
-- THIS SCRIPT RUNS THE COMPLEX QUERIES AGAINST THE MY_HOSPITAL_DB DATABASE.
-- ************************************************************************
-- 1. To get the patient details based on the dates given.
SELECT P.PATIENT_ID, P.NAME, P.DATE_OF_BIRTH,P.GENDER, P.MEDICAL_HISTORY,
		DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e') AS VISITING_DATE FROM PATIENT P 
	INNER JOIN APPOINTMENTS A 
    ON P.PATIENT_ID = A.PATIENT_ID
    WHERE DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e') = '2008-04-24';

-- 2. To get the list of staff info who belong to a particular department
SELECT S.STAFF_ID,S.NAME, S.SPECIALITY, S.DEPARTMENT_ID, S.SSN
		FROM HOSPITAL_STAFF S LEFT JOIN DEPARTMENT D
        ON S.DEPARTMENT_ID = D.DEPARTMENT_ID 
        WHERE D.DEPARTMENT_NAME = 'PHYSCIAN';

-- 3.To get list of patients who are diagnosed with Acute Spinal Cord Recovery
SELECT DISTINCT P.PATIENT_ID, P.NAME, P.GENDER, C.PRACTICE FROM APPOINTMENTS A 
			RIGHT JOIN PATIENT P ON  P.PATIENT_ID = A.PATIENT_ID
            LEFT JOIN CLINICAL_CARE_INFO C ON A.APPOINTMENT_ID = C.APPOINTMENT_ID
            WHERE C.PRACTICE = 'Acute Spinal Cord Recovery';
            
-- 4.	To get list of patients who have visited on particular date.
SELECT P.PATIENT_ID, P.NAME, P.GENDER, P.ADDRESS, 
		DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e') AS VISITING_DATE 
		FROM APPOINTMENTS A 
			LEFT JOIN PATIENT P ON P.PATIENT_ID = A.PATIENT_ID
            WHERE DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e')  = '2008-04-26';
            
            
-- 5. To get the list of patients who will be consulted by certain doctors
SELECT P.PATIENT_ID, P.NAME, P.GENDER, P.ADDRESS, S.NAME
		FROM APPOINTMENTS A 
			LEFT JOIN PATIENT P ON P.PATIENT_ID = A.PATIENT_ID
            LEFT JOIN HOSPITAL_STAFF S ON A.STAFF_ID = S.STAFF_ID
            WHERE A.STAFF_ID = '1768459648';        
            
-- 6.	To get the list of patients who visited twice within the shortest time.
SELECT  A.patient_id, p.name, p.gender, p.PHONE, p.address,
		DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e') as 'DATE_1',
        DATE_FORMAT(B.START_DATE_TIME,'%Y-%m-%e') as 'DATE_2',
        datediff (DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e'), DATE_FORMAT(B.START_DATE_TIME,'%Y-%m-%e')) as DATE_DIFF
		FROM my_hospital_db.appointments a, my_hospital_db.appointments b 
		left join patient p on b.patient_id = p.patient_id
		where a.PATIENT_ID = b.PATIENT_ID and a.APPOINTMENT_ID  <> b.appointment_id and
	(datediff (DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e'), DATE_FORMAT(B.START_DATE_TIME,'%Y-%m-%e')) BETWEEN 0 AND 2)
        ORDER BY DATE_DIFF; 

-- 7.	To get the list of patients who visited on a given day
-- with Lumbar Disk Disease as health issue.
SELECT P.PATIENT_ID, P.NAME, P.GENDER, P.ADDRESS, A.HEALTH_ISSUE
		FROM APPOINTMENTS A 
			LEFT JOIN PATIENT P ON P.PATIENT_ID = A.PATIENT_ID
            WHERE A.HEALTH_ISSUE = 'Lumbar Disk Disease';
            
-- 8. To get the number of appointments each department got on a given date.
SELECT D.DEPARTMENT_NAME, COUNT(HS.DEPARTMENT_ID) AS NO_OF_APPOINTMENTS 
		FROM APPOINTMENTS A 
			LEFT JOIN HOSPITAL_STAFF HS ON A.STAFF_ID = HS.STAFF_ID
            INNER JOIN DEPARTMENT D ON  HS.DEPARTMENT_ID = D.DEPARTMENT_ID
		WHERE DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e') = '2008-04-26'
        GROUP BY HS.DEPARTMENT_ID;
        
-- 9. To get the total billed amount on given time frame.
SELECT DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e'), a.patient_id, tb.total_bill 
		FROM APPOINTMENTS A 
			LEFT JOIN TOTAL_BILLING TB ON A.PATIENT_ID = TB.PATIENT_ID;
		-- WHERE DATE_FORMAT(A.START_DATE_TIME,'%Y-%m-%e') = '2008-04-26';
        
        
        
                
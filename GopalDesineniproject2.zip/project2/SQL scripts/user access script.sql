use MY_HOSPITAL_DB;

Flush privileges;

drop user 'receptionist'@'localhost';
drop user 'nurse'@'localhost';
drop user 'doctor'@'localhost';

create user 'receptionist'@'localhost' identified by 'receptionist';
create user 'nurse'@'localhost' identified by 'nurse';
create user 'doctor'@'localhost' identified by 'doctor';

grant all privileges on MY_HOSPITAL_DB.PATIENT to 'receptionist'@'localhost';
grant all privileges on MY_HOSPITAL_DB.APPOINTMENTS to 'receptionist'@'localhost';
grant select on MY_HOSPITAL_DB.HOSPITAL_STAFF to 'receptionist'@'localhost';
grant update,select on MY_HOSPITAL_DB.CLINICAL_CARE_INFO to 'receptionist'@'localhost';
grant update,select on MY_HOSPITAL_DB.AUDIT_CLINICAL_CARE_INFO to 'receptionist'@'localhost';
grant select on MY_HOSPITAL_DB.AUDIT_PATIENT to 'receptionist'@'localhost';
grant select on MY_HOSPITAL_DB.AUDIT_HOSPITAL_STAFF to 'receptionist'@'localhost';

GRANT execute ON PROCEDURE MY_HOSPITAL_DB.INSERT_PATIENT_INFORMATION TO 'receptionist'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.UPDATE_PATIENT_INFORMATION TO 'receptionist'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.INSERT_HOSPITAL_STAFF_INFORMATION TO 'receptionist'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.INSERT_APPOINTMENT_INFORMATION TO 'receptionist'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.INSERT_DISCHARGE_INFORMATION TO 'receptionist'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.INSERT_AVAILABILITY_INFORMATION TO 'receptionist'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.UPDATE_AVAILABILITY_INFORMATION TO 'receptionist'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.SELECT_PATIENTS_APPOINTMENTS to 'receptionist'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.SELECT_DISCHARGED_PATIENTS to 'receptionist'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.SELECT_DOCTORS_PATIENTS to 'receptionist'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.TOTAL_BILL_GENERATOR to 'receptionist'@'localhost';

-- nursing staff grants

grant all privileges on MY_HOSPITAL_DB.CLINICAL_CARE_INFO to 'nurse'@'localhost';
grant all privileges on MY_HOSPITAL_DB.AUDIT_CLINICAL_CARE_INFO to 'nurse'@'localhost';
grant select on MY_HOSPITAL_DB.PATIENT to 'nurse'@'localhost';
grant select on MY_HOSPITAL_DB.AUDIT_PATIENT to 'nurse'@'localhost';
grant select on MY_HOSPITAL_DB.HOSPITAL_STAFF to 'nurse'@'localhost';
grant select on MY_HOSPITAL_DB.AUDIT_HOSPITAL_STAFF to 'nurse'@'localhost';
grant update, select on MY_HOSPITAL_DB.MEDICATION_BUCKET to 'nurse'@'localhost';
grant select on MY_HOSPITAL_DB.LAB_PROCEDURE_BUCKET to 'nurse'@'localhost';
grant select on MY_HOSPITAL_DB.PRESCRIPTIONS to 'nurse'@'localhost';

GRANT execute ON PROCEDURE MY_HOSPITAL_DB.SELECT_PRESCRIBED_MEDICINES TO 'nurse'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.SELECT_PROCEDURES_PATIENTS to 'nurse'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.UPDATE_LAB_PROCEDURE_COST to 'nurse'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.CREATE_PRESCRIPTION TO 'nurse'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.PRESCRIBE_LAB_PROCEDURES TO 'nurse'@'localhost';
grant execute on procedure MY_HOSPITAL_DB.PRESCRIBE_MEDICINES to 'nurse'@'localhost';


-- care provider grants

grant all privileges on MY_HOSPITAL_DB.CLINICAL_CARE_INFO to 'doctor'@'localhost';
grant all privileges on MY_HOSPITAL_DB.AUDIT_CLINICAL_CARE_INFO to 'doctor'@'localhost';
grant select on MY_HOSPITAL_DB.PATIENT to 'doctor'@'localhost';
grant select on MY_HOSPITAL_DB.AUDIT_PATIENT to 'doctor'@'localhost';
grant select on MY_HOSPITAL_DB.HOSPITAL_STAFF to 'doctor'@'localhost';
grant all privileges on MY_HOSPITAL_DB.AUDIT_HOSPITAL_STAFF to 'doctor'@'localhost';
grant all privileges on MY_HOSPITAL_DB.MEDICATION_BUCKET to 'doctor'@'localhost';
grant select on MY_HOSPITAL_DB.LAB_PROCEDURE_BUCKET to 'doctor'@'localhost';
grant select on MY_HOSPITAL_DB.PRESCRIPTIONS to 'doctor'@'localhost';

GRANT execute ON PROCEDURE MY_HOSPITAL_DB.SELECT_PRESCRIBED_MEDICINES TO 'doctor'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.SELECT_PROCEDURES_PATIENTS TO 'doctor'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.UPDATE_LAB_PROCEDURE_COST TO 'doctor'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.CREATE_PRESCRIPTION TO 'doctor'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.PRESCRIBE_LAB_PROCEDURES TO 'doctor'@'localhost';
GRANT execute ON PROCEDURE MY_HOSPITAL_DB.PRESCRIBE_MEDICINES TO 'doctor'@'localhost';



